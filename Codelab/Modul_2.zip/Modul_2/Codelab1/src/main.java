// Kelas buat nyimpen data hewan
class Hewan {
    // Atribut buat nyimpen nama hewan
    String Nama;
    // Atribut buat nyimpen jenis hewan (Mamalia, Reptil, dll.)
    String Jenis;
    // Atribut buat nyimpen suara hewan
    String Suara;

    // Method buat nampilin info hewan ke layar
    void tampilkanInfo() {
        System.out.println("Nama: " + Nama);
        System.out.println("Jenis: " + Jenis);
        System.out.println("Suara: " + Suara);
        System.out.println();
    }
}

// Kelas utama buat ngejalanin program
public class main {
    public static void main(String[] args) {
        // Bikin objek hewan pertama (Kucing)
        Hewan hewan1 = new Hewan();
        hewan1.Nama = "Kucing";
        hewan1.Jenis = "Mamalia";
        hewan1.Suara = "Nyann~~";

        // Bikin objek hewan kedua (Anjing)
        Hewan hewan2 = new Hewan();
        hewan2.Nama = "Anjing";
        hewan2.Jenis = "Mamalia";
        hewan2.Suara = "Woof-Woof!";

        // Nampilin informasi kedua hewan
        hewan1.tampilkanInfo();
        hewan2.tampilkanInfo();
    }
}
