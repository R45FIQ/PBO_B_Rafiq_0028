public class StokTidakCukupException extends Exception {
  public StokTidakCukupException(String pesan) {
    super(pesan);
  }
}
