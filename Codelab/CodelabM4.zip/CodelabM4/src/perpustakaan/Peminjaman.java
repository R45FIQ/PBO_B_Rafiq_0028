package perpustakaan;

public interface Peminjaman {
    void pinjamBuku(Buku buku);
    void kembaliBuku(Buku buku);
}